import React, { Component } from 'react';
import './App.css';
import Characters from './components/characters';

class App extends Component {
  constructor() {
    super();
    this.displayData = [];
    this.checkedItems = [];
    this.isChecked = false;
    this.isUncheckedItems = false;
    this.uniqueoriginArray = [];
    this.uniqueGenderArray = [];
    this.uniqueSpeciesArray = [];
    this.state = {
      characters: [],
      isAsc : 'ascending',
      duplicateChar: [],
      forFilterChar: [],
      options: [
        {
          name: 'Ascending',
          value: 'ascending',
        },
        {
          name: 'Descending',
          value: 'descending',
        },
      ],
    }    
  }
  componentDidMount() {
    this.apiCall();
  }
  apiCall = () => {
    fetch('https://rickandmortyapi.com/api/character/')
    .then(res => res.json())
    .then((data) => {
      data.results.sort((a, b) => a.name - b.name);
      this.setState({ characters: data.results })
      this.setState({ duplicateChar: data.results })
      this.setState({ forFilterChar: data.results })
    })
    .catch(console.log)
  }
  handleCheckboxChange = (e) => {
    if(e.target.checked) {
      this.isChecked = true;
      this.checkedItems.push(e.target.value);
      this.displayData.push(<span className="filteredItemsValue" onClick={this.filterClear.bind(this,e.target.value)}><span>{e.target.value}</span>x</span>);
      if(this.checkedItems.length > 0) {
        this.filterCharacters(this.checkedItems);
      }
    } else {
      var index = this.checkedItems.indexOf(e.target.value);
      if (index > -1) {
        this.checkedItems.splice(index, 1);
      }
      var filteredItemsValue = document.getElementsByClassName('filteredItemsValue');
      for(var k=0; k<filteredItemsValue.length; k++) {
        if(filteredItemsValue[k].innerText === e.target.value+'x') {
          filteredItemsValue[k].remove();
        }
      }
      this.isUncheckedItems = true;
      this.filterCharacters(this.checkedItems);
    }
  }
  filterClear = (e) => {
    var index = this.checkedItems.indexOf(e);
    if (index > -1) {
      this.checkedItems.splice(index, 1);
    }
    var checkbox = document.getElementsByClassName('check');
    for(var i=0; i<checkbox.length; i++) {
      if(checkbox[i].value == e) {
        checkbox[i].checked = false;
      }
    }
    var filteredItemsValue = document.getElementsByClassName('filteredItemsValue');
      for(var k=0; k<filteredItemsValue.length; k++) {
        if(filteredItemsValue[k].innerText === e+'x') {
          filteredItemsValue[k].remove();
        }
      }
      this.filterCharacters(this.checkedItems);
  }
  handleChange = (event) => {
    this.setState({ value: event.target.value });
    this.setState({ isAsc: event.target.value });
  };
  filterCharacters = (itemsChecked) => {
    var charFilters = [];
    var species=[], gender=[], origin=[];
    if(itemsChecked.length > 0) {
      for(var it=0; it<itemsChecked.length;it++){
        if(this.uniqueSpeciesArray.indexOf(itemsChecked[it]) > -1){
          species.push(itemsChecked[it]);
        }
        if(this.uniqueGenderArray.indexOf(itemsChecked[it]) > -1){
          gender.push(itemsChecked[it]);
        }
        if(this.uniqueoriginArray.indexOf(itemsChecked[it]) > -1){
          origin.push(itemsChecked[it]);
        }
      }
    } 
      var items = this.state.characters;
    for(var characters=0; characters<items.length; characters++) {
      if((!gender.length || gender.indexOf(items[characters].gender) > -1 ) && (!species.length || species.indexOf(items[characters].species) > -1) && (!origin.length || origin.indexOf(items[characters].origin['name']) > -1))  {
        charFilters.push(items[characters]); 
      }
    } 
    this.setState({
      forFilterChar : charFilters
    })
  }
  render = () => {
    /* Sorting Characters list here */
    var items = this.state.forFilterChar;
    var itemsDup = this.state.duplicateChar;
    var uiList = [];
    if(this.state.isAsc === "ascending") {
      items.sort(function(a,b) {
        var nameA = a.name.toUpperCase(); // ignore upper and lowercase
        var nameB = b.name.toUpperCase();
        if (nameA < nameB) {
          return -1;
        }
        if (nameA > nameB) {
          return 1;
        }
      })
    } else {
      items.sort(function(a,b) {
        var nameA = a.name.toUpperCase(); // ignore upper and lowercase
        var nameB = b.name.toUpperCase();
        if (nameA > nameB) {
          return -1;
        }
        if (nameA < nameB) {
          return 1;
        }
      })
    }
    /* Get Unique Species, Gender, Origin from the API */    
    for(var m=0; m < itemsDup.length; m++){
      /* Unique Origin Values */
      if(this.uniqueoriginArray.indexOf(itemsDup[m].origin['name']) === -1) {
        this.uniqueoriginArray.push(itemsDup[m].origin['name']);
      }
      /* Unique Gender Values */
      if(this.uniqueGenderArray.indexOf(itemsDup[m].gender) === -1) {
        this.uniqueGenderArray.push(itemsDup[m].gender);
      }
      /* Unique Species Values */
        if(this.uniqueSpeciesArray.indexOf(itemsDup[m].species) === -1) {
          this.uniqueSpeciesArray.push(itemsDup[m].species);
      }
    }
    this.uniqueoriginArray.splice(this.uniqueoriginArray.indexOf('unknown'), 1)
    this.uniqueGenderArray.splice(this.uniqueGenderArray.indexOf('unknown'), 1)
    
    var originArray = [];
    for(var j=0; j<this.uniqueoriginArray.length; j++) {
        originArray.push(<div className="checkbox" onChange={this.handleCheckboxChange}><input className="check" type="checkbox" value={this.uniqueoriginArray[j]}></input><span className="filteredSpecies" key={this.uniqueoriginArray[j]}>{this.uniqueoriginArray[j]}</span></div>)
    }
    var genderArray = [];
    for(var j=0; j<this.uniqueGenderArray.length; j++) {
      genderArray.push(<div className="checkbox" onChange={this.handleCheckboxChange}><input className="check"  type="checkbox" value={this.uniqueGenderArray[j]}></input><span className="filteredSpecies" key={this.uniqueGenderArray[j]}>{this.uniqueGenderArray[j]}</span></div>)
    }
    var speciesArray = [];
    for(var j=0; j<this.uniqueSpeciesArray.length; j++) {
      speciesArray.push(<div className="checkbox" onChange={this.handleCheckboxChange}><input className="check"  type="checkbox" value={this.uniqueSpeciesArray[j]}></input><span className="filteredSpecies" key={this.uniqueSpeciesArray[j]}>{this.uniqueSpeciesArray[j]}</span></div>)
    }
    return (
      <div className="container-fluid">
        <div className="row">
          <div className="col-xs-12 col-md-2 col-sm-12 filterAreas">
              <div className="filtersSection">
                <h3 className="filterTitle">Filters</h3>
                <div className="sectionFilters">
                  <h5>Species</h5>
                  <div className="noOfSpecies">
                    {speciesArray}
                  </div>
                </div>
                <div className="sectionFilters">
                  <h5>Gender</h5>
                  <div className="noOfSpecies">
                    {genderArray} 
                  </div>
                </div>
                <div className="sectionFilters">
                  <h5>Origin</h5>
                  <div className="noOfSpecies">
                     {originArray} 
                  </div>
                </div>
              </div>
          </div>
          <div className="container col-xs-10 col-10">
            <div className="areaofFilters">
              <div className="filteredSection">
                <h5 className="filterHead">Selected Filters</h5>
                <div className="noOfItems">
                  {this.displayData}
                </div>
              </div>
              <div className="sorting">
              <select onChange={this.handleChange} value={this.state.value}>
                  {this.state.options.map(item => (
                    <option key={item.value} value={item.value}>{item.name}</option>
                  ))}
              </select>
              </div>
            </div>
              <Characters key={this.state.characters} charLists={items} />
          </div>
        </div>
      </div>
    );
  }
}

export default App;

/* name
id ,created

status
species
gender
origin
lastlocation */

import React from 'react';

const Characters = (props) => {
        if (props.charLists.length > 0) {
            var characterLists = [];
            characterLists = (props.charLists.map((character, index) => {
                    var d = new Date('2017-11-04T18:48:46.250Z');
                    var dates = new Date();
                    var r = dates.getFullYear();
                    var n = d.getFullYear();
                    return <div className="card col-sm-3 col-md-3">
                        <div className="card-body">
                        <div className="imgSection">
                            <img src={character.image} alt="{character.name}"></img>
                            <div className="titleSection">
                                <h5 className="card-title">{character.name}</h5>
                                <span className="idSection">id: {character.id} - Created {r-n} years ago</span>
                            </div>
                        </div>
                        <div className="characterContentSection">
                            <span className="charStatusDetails">
                                <span className="charStatusTitle">Status</span>
                                <span className="charStatusDesc">{character.status}</span>
                            </span>
                            <span className="charStatusDetails">
                                <span className="charStatusTitle">Species</span>
                                <span className="charStatusDesc">{character.species}</span>
                            </span>
                            <span className="charStatusDetails">
                                <span className="charStatusTitle">Gender</span>
                                <span className="charStatusDesc">{character.gender}</span>
                            </span>
                            <span className="charStatusDetails">
                                <span className="charStatusTitle">Origin</span>
                                <span className="charStatusDesc">{character.origin['name']}</span>
                            </span>
                        </div>
                    </div>
                </div>
            }));
        } else {
          characterLists = (<p>No Results found</p>);
        }
    return (
        <div className="row"> 
            {characterLists}
        </div>
    )
    };

    export default Characters